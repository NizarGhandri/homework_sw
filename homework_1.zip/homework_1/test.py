#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 16:31:49 2019

@author: nizar
""" 
import pytest
from partition import partition, sort
from bheap import BinHeap
from hypothesis import given
import hypothesis.strategies as st
import random

#---------------- tests for partition and sort --------------
@given (st.lists(st.integers()), st.integers())
def test_partition(a, r): 
    end = len(a)
    start = random.randint(0, end)
    (i, j) = partition(a, r, start, end) 
    print(i, j)
    for k in range (start, i):
        assert a[k] < r
    for k in range (i, j):
        assert a[k] == r
    for k in range (j, end):
        assert a[k] > r
        
@given (st.lists(st.integers()), st.integers())
def test_raisesCorrectException(a, r): 
    with pytest.raises(ValueError):
        partition(a, r, -1, len(a))
    with pytest.raises(ValueError):
        partition(a, r, len(a)+1, len(a))
    with pytest.raises(ValueError):
        partition(a, r, 0, len(a)+1)
    
@given (st.lists(st.integers()))
def test_sort(a):
    print(a)
    end = len(a)
    start = 0
    sort(a, start, end)
    print(a)
    for i in range (start, end-1): 
        assert a[i] <= min(a[i+1:])
        

    
    
    