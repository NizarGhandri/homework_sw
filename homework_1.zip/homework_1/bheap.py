﻿# Ce fichier contient (au moins) cinq erreurs.
# Instructions:
#  - tester jusqu'à atteindre 100% de couverture;
#  - corriger les bugs;
#  - envoyer le diff ou le dépôt git par email.

class BinHeap:
    def __init__(self):
        self.heapList = [0]
        self.currentSize = 1

    def percUp(self,i):
        j = i
        if (j < self.currentSize):
            while j!=0 and  self.heapList[j] > self.heapList[j // 2]:
                 tmp = self.heapList[j // 2]
                 self.heapList[j // 2] = self.heapList[j]
                 self.heapList[j] = tmp
                 j = j // 2

    def insert(self,k):
      self.heapList.append(k)
      self.currentSize = self.currentSize + 1
      self.percUp(self.currentSize)

    def percDown(self,i):
      while (i * 2) < self.currentSize:
          mc = self.minChild(i)
          if self.heapList[i] > self.heapList[mc]:
              tmp = self.heapList[i]
              self.heapList[i] = self.heapList[mc]
              self.heapList[mc] = tmp
          i = mc

    def minChild(self,i):
      if i * 2 + 1 >= self.currentSize:
          return i * 2
      else:
          if self.heapList[i*2] < self.heapList[i*2+1]:
              return i * 2
          else:
              return i * 2 + 1

    def delMin(self):
      if (self.currentSize < 1):
          raise ValueError("can't get/del min of empty heap")
      retval = self.heapList[1]
      self.heapList[1] = self.heapList[self.currentSize]
      self.currentSize = self.currentSize - 1
      self.heapList.pop()
      self.percDown(1)
      return retval

    def buildHeap(self,alist):
      i = len(alist) // 2
      self.currentSize = len(alist) +1 
      self.heapList = [0] + alist[:]
      while (i > 0):
          self.percDown(i)
          i = i - 1

