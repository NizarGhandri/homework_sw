#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 16:30:23 2019

@author: nizar
"""
def partition (array, pivot, start, end): 
    
    if(start < 0 or start > end or end > len(array)):
        raise ValueError()
    
    i = start
    j = start
    k = end - 1
    
    while i <= k: 
        if (array[i] < pivot): 
            array [i], array[j] = array[j], array[i]
            i = i+1
            j = j+1
        elif (array[i] > pivot):
            array [i], array[k] = array[k], array[i]
            k = k-1
        else: 
            i = i+1

    return j,k+1



def sort (array, start, end):
    if ((end - start) < 2): 
        return 1
    else:
        i,j = partition(array, array[start], start, end)
        sort(array, start, i)
        sort(array, j, end)


