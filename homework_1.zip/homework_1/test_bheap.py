#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 17:48:23 2019

@author: nizar
"""

import pytest
from bheap import BinHeap
from hypothesis import given
import hypothesis.strategies as st


def test_constructor_builds_list_with_zero_elements (): 
    heap = BinHeap()
    assert heap.heapList == [0] and heap.currentSize == 1
 
@given (st.lists(st.integers()))
def test_percUp (a):
    heap = BinHeap()
    heap.heapList = [0] + sorted(a)
    for i in range (1, len(a)):
        b = heap.heapList.copy()
        heap.heapList.append(heap.heapList[i])
        heap.currentSize = len(a) + 1
        heap.percUp(heap.currentSize)
        heap.heapList = b
        assert isBinaryHeap(heap)
        
        
@given (st.lists(st.integers()), st.integers())
def test_insert (a, i): 
    heap = BinHeap()
    heap.heapList = [0] + sorted(a)
    size = heap.currentSize
    heap.insert(i)
    assert isBinaryHeap(heap) and heap.currentSize == size + 1
    
def isBinaryHeap (heap): 
    for i in range (1, heap.currentSize//2):
        if heap.heapList[i] > heap.heapList[2*i] or heap.heapList[i] > heap.heapList[2*i +1]:
            return False
    return True

@given (st.lists(st.integers()))
def test_percDown (a):
    heap = BinHeap()
    heap.heapList = [0] + sorted(a)
    for i in range (1, len(a)):
        b = heap.heapList.copy()
        heap.heapList = [heap.heapList[heap.currentSize - 1 - i]] + heap.heapList
        heap.currentSize = len(a) + 1
        heap.percUp(heap.currentSize)
        heap.heapList = b
        assert isBinaryHeap(heap)

@given (st.lists(st.integers()))
def test_minChild (a): 
    heap = BinHeap()
    heap.heapList = [0] + sorted(a)
    for i in range (1, heap.currentSize//2): 
        if (2*i +1 < heap.currentSize ):
            assert heap.heapList[heap.minChild(i)] == min(heap.heapList[2*i], heap.heapList[2*i + 1])
 
@given (st.lists(st.integers(), min_size = 1))           
def test_delMin(a):
    heap = BinHeap()
    heap.heapList = [0] + sorted(a)
    assert heap.delMin() == min(a) and isBinaryHeap(heap)
    
@given (st.lists(st.integers(), min_size = 1))
def test_buildBinHeap (a): 
    heap = BinHeap()
    heap.buildHeap(a)
    print(heap.heapList)
    assert isBinaryHeap(heap) and heap.currentSize == len(a) + 1